#!/bin/bash

cat plots/data/$1/$2/"$2""$1"00"$3"rad.dat
