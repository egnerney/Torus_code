#!/bin/bash

make clean
rm *D.dat
rm intens*
