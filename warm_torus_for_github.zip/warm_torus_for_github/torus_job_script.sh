#!/bin/bash

#SBATCH --account=ucb217_summit1
#SBATCH --nodes=4
#SBATCH --ntasks=80
#SBATCH --time=03:00:00
#SBATCH --partition=shas
#SBATCH --output=1000dayrun_dt_14_2node_32tasks_torus_2x16_cold_torus_only-%j.out

ulimit -n 4096
ulimit stack unlimited
ulimit filesize unlimited
ulimit datasize unlimited
ulimit memoryuse unlimited
ulimit memorylocked unlimited
ulimit descriptors 4096
ulimit maxproc unlimited
ulimit cputime unlimited

module purge
#module load gcc openmpi
module load intel impi
echo "== This is the scripting step! =="
date
export lng=2
export rad=160
export npes=$(($rad * $lng))
export days=$( cat inputs.dat | head -n 21 | tail -n 1 | head -c 3 )
export SLURM_EXPORT_ENV=ALL
./changeDimension.sh $rad $lng

echo "*YIPPEEEE**"
cd /scratch/summit/edne8319/cold_torus_only
mpirun  -np $npes ./torus >> runlog
make clean
module purge
module load python
./moveData.sh $rad $lng
date
echo "== End of job =="
