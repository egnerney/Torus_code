#!/bin/bash

display spmix.jpeg &
display s2pmix.jpeg &
display s3pmix.jpeg &
display opmix.jpeg &
display o2pmix.jpeg 
