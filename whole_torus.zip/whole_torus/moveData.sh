#!/bin/bash

mv DENS*.dat plots/.
mv MIXR*.dat plots/.
mv TEMP*.dat plots/.
#mv INTS*.dat plots/.  
mv NL2_*.dat plots/.
mv LOAD*.dat plots/.
mv MOUT*.dat plots/.
mv TMSS*.dat plots/.
mv VSUB*.dat plots/.
#mv intensity*.dat plots/.  
mv PUV*.dat plots/.
mv FEH*.dat plots/.
mv ENTR*.dat plots/.

mv mf1_*.dat plots/.
mv mf2_*.dat plots/.
mv mf3_*.dat plots/.
mv mf4_*.dat plots/.
mv mf5_*.dat plots/.
mv mf6_*.dat plots/.
mv mf7_*.dat plots/.
mv mf8_*.dat plots/.
mv mf9_*.dat plots/.
mv mf10_*.dat plots/.
mv mf11_*.dat plots/.
mv mf12_*.dat plots/.
mv mf13_*.dat plots/.
mv mf14_*.dat plots/.
mv mf15_*.dat plots/.

mv ef1_*.dat plots/.
mv ef2_*.dat plots/.
mv ef3_*.dat plots/.
mv ef4_*.dat plots/.
mv ef5_*.dat plots/.
mv ef6_*.dat plots/.
mv ef7_*.dat plots/.
mv ef8_*.dat plots/.
mv ef9_*.dat plots/.
mv ef10_*.dat plots/.
mv ef11_*.dat plots/.
mv ef12_*.dat plots/.
mv ef13_*.dat plots/.
mv ef14_*.dat plots/.
mv ef15_*.dat plots/.
mv ef16_*.dat plots/.
mv ef17_*.dat plots/.
mv ef18_*.dat plots/.
mv ef19_*.dat plots/.
mv ef20_*.dat plots/.
mv ef21_*.dat plots/.
mv ef22_*.dat plots/.
mv ef23_*.dat plots/.
mv ef24_*.dat plots/.
mv ef25_*.dat plots/.
#mv ERAT*.dat plots/.

cd plots

  python radData.py $1 $2

  mv DENS*.dat data/.
  mv MIXR*.dat data/.
  mv TEMP*.dat data/.
#  mv INTS*.dat data/.
  mv NL2_*.dat data/.
  mv LOAD*.dat data/.
  mv MOUT*.dat data/.
  mv TMSS*.dat data/.
  mv PUV*.dat data/.
  mv VSUB*.dat data/.
  mv FEH*.dat data/.
  mv ENTR*.dat data/.
 # mv ERAT*.dat data/.
  #  rm intensity*.dat

  mv mf1_*.dat data/.
  mv mf2_*.dat data/.
  mv mf3_*.dat data/.
  mv mf4_*.dat data/.
  mv mf5_*.dat data/.
  mv mf6_*.dat data/.
  mv mf7_*.dat data/.
  mv mf8_*.dat data/.
  mv mf9_*.dat data/.
  mv mf10_*.dat data/.
  mv mf11_*.dat data/.
  mv mf12_*.dat data/.
  mv mf13_*.dat data/.
  mv mf14_*.dat data/.
  mv mf15_*.dat data/.
 
  mv ef1_*.dat data/.
  mv ef2_*.dat data/.
  mv ef3_*.dat data/.
  mv ef4_*.dat data/.
  mv ef5_*.dat data/.
  mv ef6_*.dat data/.
  mv ef7_*.dat data/.
  mv ef8_*.dat data/.
  mv ef9_*.dat data/.
  mv ef10_*.dat data/.
  mv ef11_*.dat data/.
  mv ef12_*.dat data/.
  mv ef13_*.dat data/.
  mv ef14_*.dat data/.
  mv ef15_*.dat data/.
  mv ef16_*.dat data/.
  mv ef17_*.dat data/.
  mv ef18_*.dat data/.
  mv ef19_*.dat data/.
  mv ef20_*.dat data/.
  mv ef21_*.dat data/.
  mv ef22_*.dat data/.
  mv ef23_*.dat data/.
  mv ef24_*.dat data/.
  mv ef25_*.dat data/.
  ./organize.sh

cd ..
